# 🛒 Supermarket Management System
### Full-Stack MEAN Stack Application

A complete supermarket management system with Admin and Customer panels, built with **MongoDB, Express.js, Angular 17, Node.js**.

---

## 📁 Project Structure

```
supermarket/
├── backend/         → Node.js + Express + MongoDB API
│   ├── controllers/ → Business logic
│   ├── models/      → Mongoose schemas
│   ├── routes/      → API endpoints
│   ├── middleware/  → JWT auth middleware
│   ├── server.js    → Entry point
│   ├── seed.js      → Sample data seeder
│   └── .env         → Environment variables
└── frontend/        → Angular 17 SPA
    └── src/app/
        ├── components/
        │   ├── admin/    → Dashboard, Products, Users, Orders
        │   ├── user/     → Home, Cart, My Orders
        │   ├── auth/     → Login, Register
        │   └── shared/   → Navbar
        ├── services/     → API service layer
        ├── guards/       → Route guards + JWT interceptor
        └── models/       → TypeScript interfaces
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js v18+
- MongoDB (local or MongoDB Atlas)
- Angular CLI: `npm install -g @angular/cli`

---

### 1. Backend Setup

```bash
cd backend
npm install
```

Edit `.env` to point to your MongoDB:
```
MONGO_URI=mongodb://localhost:27017/supermarket_db
JWT_SECRET=your_secret_key
```

Seed the database with sample data:
```bash
node seed.js
```

Start the backend server:
```bash
npm run dev
```
Backend runs on → **http://localhost:5000**

---

### 2. Frontend Setup

```bash
cd frontend
npm install
ng serve
```
Frontend runs on → **http://localhost:4200**

---

## 🔑 Default Login Credentials (after seeding)

| Role  | Email                   | Password   |
|-------|-------------------------|------------|
| Admin | admin@supermart.com     | admin123   |
| User  | user@supermart.com      | user123    |

---

## 📡 API Endpoints

### Auth
| Method | Endpoint             | Access  | Description        |
|--------|----------------------|---------|--------------------|
| POST   | /api/auth/register   | Public  | Register new user  |
| POST   | /api/auth/login      | Public  | Login              |
| GET    | /api/auth/me         | Private | Get current user   |

### Products
| Method | Endpoint              | Access  | Description            |
|--------|-----------------------|---------|------------------------|
| GET    | /api/products         | Public  | Get all products       |
| GET    | /api/products/:id     | Public  | Get single product     |
| GET    | /api/products/stats   | Admin   | Dashboard statistics   |
| POST   | /api/products         | Admin   | Create product         |
| PUT    | /api/products/:id     | Admin   | Update product         |
| DELETE | /api/products/:id     | Admin   | Delete product         |

### Orders
| Method | Endpoint                   | Access  | Description           |
|--------|----------------------------|---------|-----------------------|
| POST   | /api/orders                | User    | Place order           |
| GET    | /api/orders/my             | User    | Get my orders         |
| GET    | /api/orders                | Admin   | Get all orders        |
| PUT    | /api/orders/:id/status     | Admin   | Update order status   |

### Users (Admin)
| Method | Endpoint          | Access | Description      |
|--------|-------------------|--------|------------------|
| GET    | /api/users        | Admin  | Get all users    |
| DELETE | /api/users/:id    | Admin  | Delete user      |

---

## ✨ Features

### Admin Panel
- 📊 Dashboard with live stats (products, users, orders, out-of-stock)
- 📦 Product CRUD with category filter
- 🚦 Out-of-Stock badge — dynamic from `stockQuantity`
- 👥 User management with delete
- 📋 Order management with status updates

### Customer Panel
- 🏠 Home page with product browse & search
- 🗂 Filter by category (Groceries, Vegetables, Fruits, Household, Ice-cream)
- 🛒 Cart with add/update/remove + persistent across sessions
- ✅ Checkout with stock validation
- 📦 My Orders with status tracking

### System
- 🔐 JWT Authentication with role-based access
- 🔒 Protected routes (authGuard, adminGuard)
- 🌐 HTTP Interceptor auto-attaches JWT to requests
- 💾 Cart persisted in localStorage

---

## 🛠 Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| Frontend  | Angular 17 (Standalone Components)|
| Styling   | Bootstrap 5 + Bootstrap Icons     |
| Backend   | Node.js + Express.js              |
| Database  | MongoDB + Mongoose                |
| Auth      | JWT (jsonwebtoken + bcryptjs)     |
