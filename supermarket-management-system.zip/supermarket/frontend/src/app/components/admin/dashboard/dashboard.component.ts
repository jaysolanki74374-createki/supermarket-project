import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProductService } from '../../../services/product.service';
import { DashboardStats } from '../../../models/models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container-fluid py-4">
      <h2 class="fw-bold mb-4"><i class="bi bi-speedometer2 me-2 text-success"></i>Admin Dashboard</h2>

      <div class="text-center py-5" *ngIf="loading">
        <div class="spinner-border text-success"></div>
      </div>

      <div class="row g-4" *ngIf="!loading && stats">
        <!-- Stat Cards -->
        <div class="col-sm-6 col-xl-3">
          <div class="stat-card" style="background:linear-gradient(135deg,#2e7d32,#66bb6a);">
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <p class="mb-1 opacity-75">Total Products</p>
                <h2 class="mb-0 fw-bold">{{stats.totalProducts}}</h2>
              </div>
              <i class="bi bi-box-seam fs-1 opacity-50"></i>
            </div>
            <a routerLink="/admin/products" class="text-white-50 small mt-2 d-block">Manage Products →</a>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="stat-card" style="background:linear-gradient(135deg,#1565c0,#42a5f5);">
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <p class="mb-1 opacity-75">Total Users</p>
                <h2 class="mb-0 fw-bold">{{stats.totalUsers}}</h2>
              </div>
              <i class="bi bi-people fs-1 opacity-50"></i>
            </div>
            <a routerLink="/admin/users" class="text-white-50 small mt-2 d-block">Manage Users →</a>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="stat-card" style="background:linear-gradient(135deg,#e65100,#ffa726);">
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <p class="mb-1 opacity-75">Total Orders</p>
                <h2 class="mb-0 fw-bold">{{stats.totalOrders}}</h2>
              </div>
              <i class="bi bi-bag-check fs-1 opacity-50"></i>
            </div>
            <a routerLink="/admin/orders" class="text-white-50 small mt-2 d-block">View Orders →</a>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="stat-card" style="background:linear-gradient(135deg,#b71c1c,#ef5350);">
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <p class="mb-1 opacity-75">Out of Stock</p>
                <h2 class="mb-0 fw-bold">{{stats.outOfStock}}</h2>
              </div>
              <i class="bi bi-exclamation-triangle fs-1 opacity-50"></i>
            </div>
            <a routerLink="/admin/products" class="text-white-50 small mt-2 d-block">View Products →</a>
          </div>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="row g-4 mt-2">
        <div class="col-12"><h5 class="fw-bold">Quick Actions</h5></div>
        <div class="col-md-4">
          <div class="card border-0 shadow-sm p-3 text-center h-100">
            <i class="bi bi-plus-circle text-success" style="font-size:2.5rem;"></i>
            <h6 class="mt-2 fw-semibold">Add New Product</h6>
            <a routerLink="/admin/products" class="btn btn-success btn-sm mt-2">Go to Products</a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card border-0 shadow-sm p-3 text-center h-100">
            <i class="bi bi-people text-primary" style="font-size:2.5rem;"></i>
            <h6 class="mt-2 fw-semibold">Manage Users</h6>
            <a routerLink="/admin/users" class="btn btn-primary btn-sm mt-2">Go to Users</a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card border-0 shadow-sm p-3 text-center h-100">
            <i class="bi bi-clipboard-data text-warning" style="font-size:2.5rem;"></i>
            <h6 class="mt-2 fw-semibold">View All Orders</h6>
            <a routerLink="/admin/orders" class="btn btn-warning btn-sm mt-2">Go to Orders</a>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DashboardComponent implements OnInit {
  stats: DashboardStats | null = null;
  loading = true;

  constructor(private productSvc: ProductService) {}

  ngOnInit(): void {
    this.productSvc.getStats().subscribe({
      next: (res) => { this.stats = res.stats; this.loading = false; },
      error: () => this.loading = false
    });
  }
}
