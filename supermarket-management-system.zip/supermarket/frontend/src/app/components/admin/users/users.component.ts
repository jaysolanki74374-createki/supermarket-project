import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserService } from '../../../services/user.service';
import { User } from '../../../models/models';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container-fluid py-4">
      <h2 class="fw-bold mb-4"><i class="bi bi-people me-2 text-primary"></i>User Management</h2>

      <div class="alert alert-success" *ngIf="successMsg">
        <i class="bi bi-check-circle me-2"></i>{{successMsg}}
      </div>

      <div class="text-center py-5" *ngIf="loading">
        <div class="spinner-border text-primary"></div>
      </div>

      <div class="card border-0 shadow-sm" *ngIf="!loading">
        <div class="card-header bg-white fw-semibold">
          Total Registered Customers: <span class="badge bg-primary">{{users.length}}</span>
        </div>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Joined</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let user of users; let i = index">
                <td>{{i + 1}}</td>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center"
                         style="width:38px;height:38px;font-size:1rem;font-weight:700;">
                      {{user.name[0].toUpperCase()}}
                    </div>
                    <span class="fw-semibold">{{user.name}}</span>
                  </div>
                </td>
                <td>{{user.email}}</td>
                <td><span class="badge bg-secondary">{{user.role | titlecase}}</span></td>
                <td>{{user.createdAt ? (user.createdAt | date:'mediumDate') : 'N/A'}}</td>
                <td>
                  <button class="btn btn-sm btn-outline-danger" (click)="deleteUser(user._id, user.name)">
                    <i class="bi bi-trash me-1"></i>Delete
                  </button>
                </td>
              </tr>
              <tr *ngIf="users.length === 0">
                <td colspan="6" class="text-center text-muted py-4">No users registered yet.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class UsersComponent implements OnInit {
  users: (User & { createdAt?: string })[] = [];
  loading = true;
  successMsg = '';

  constructor(private userSvc: UserService) {}

  ngOnInit(): void { this.loadUsers(); }

  loadUsers(): void {
    this.loading = true;
    this.userSvc.getAllUsers().subscribe({
      next: (res) => { this.users = res.users as any; this.loading = false; },
      error: () => this.loading = false
    });
  }

  deleteUser(id: string, name: string): void {
    if (!confirm(`Delete user "${name}"? This cannot be undone.`)) return;
    this.userSvc.deleteUser(id).subscribe({
      next: () => {
        this.successMsg = `User "${name}" deleted successfully.`;
        this.users = this.users.filter(u => u._id !== id);
        setTimeout(() => this.successMsg = '', 3000);
      }
    });
  }
}
