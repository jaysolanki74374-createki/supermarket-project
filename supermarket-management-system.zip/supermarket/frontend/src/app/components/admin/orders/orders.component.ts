import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OrderService } from '../../../services/order.service';
import { Order } from '../../../models/models';

@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container-fluid py-4">
      <h2 class="fw-bold mb-4"><i class="bi bi-clipboard-data me-2 text-warning"></i>Order Management</h2>

      <div class="text-center py-5" *ngIf="loading">
        <div class="spinner-border text-warning"></div>
      </div>

      <div class="card border-0 shadow-sm" *ngIf="!loading">
        <div class="card-header bg-white fw-semibold">
          Total Orders: <span class="badge bg-warning text-dark">{{orders.length}}</span>
        </div>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Items</th>
                <th>Total</th>
                <th>Date</th>
                <th>Status</th>
                <th>Update</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let order of orders">
                <td><code>#{{order._id.slice(-8).toUpperCase()}}</code></td>
                <td>
                  <div class="fw-semibold">{{getCustomerName(order)}}</div>
                  <small class="text-muted">{{getCustomerEmail(order)}}</small>
                </td>
                <td>
                  <span *ngFor="let item of order.products" class="d-block small">
                    {{item.name}} x{{item.quantity}}
                  </span>
                </td>
                <td class="fw-bold text-success">₹{{order.totalAmount}}</td>
                <td><small>{{order.createdAt | date:'mediumDate'}}</small></td>
                <td>
                  <span class="badge rounded-pill" [ngClass]="getStatusClass(order.status)">
                    {{order.status | titlecase}}
                  </span>
                </td>
                <td>
                  <select class="form-select form-select-sm" style="min-width:130px;"
                    [value]="order.status" (change)="updateStatus(order, $any($event.target).value)">
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </td>
              </tr>
              <tr *ngIf="orders.length === 0">
                <td colspan="7" class="text-center text-muted py-4">No orders found.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class OrdersComponent implements OnInit {
  orders: Order[] = [];
  loading = true;

  constructor(private orderSvc: OrderService) {}

  ngOnInit(): void {
    this.orderSvc.getAllOrders().subscribe({
      next: (res) => { this.orders = res.orders; this.loading = false; },
      error: () => this.loading = false
    });
  }

  getCustomerName(order: Order): string {
    return typeof order.user === 'object' ? order.user.name : 'N/A';
  }

  getCustomerEmail(order: Order): string {
    return typeof order.user === 'object' ? order.user.email : '';
  }

  getStatusClass(status: string): string {
    const map: any = {
      pending: 'bg-warning text-dark',
      processing: 'bg-info text-dark',
      shipped: 'bg-primary',
      delivered: 'bg-success',
      cancelled: 'bg-danger'
    };
    return map[status] || 'bg-secondary';
  }

  updateStatus(order: Order, status: string): void {
    this.orderSvc.updateOrderStatus(order._id, status).subscribe({
      next: (res) => {
        order.status = res.order.status;
      }
    });
  }
}
