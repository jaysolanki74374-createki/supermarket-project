import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../../services/product.service';
import { Product } from '../../../models/models';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container-fluid py-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0"><i class="bi bi-box-seam me-2 text-success"></i>Product Management</h2>
        <button class="btn btn-success fw-semibold" (click)="openModal()">
          <i class="bi bi-plus-lg me-1"></i> Add Product
        </button>
      </div>

      <!-- Alerts -->
      <div class="alert alert-success alert-dismissible" *ngIf="successMsg">
        <i class="bi bi-check-circle me-2"></i>{{successMsg}}
        <button type="button" class="btn-close" (click)="successMsg=''"></button>
      </div>
      <div class="alert alert-danger" *ngIf="errorMsg">{{errorMsg}}</div>

      <!-- Category Filter -->
      <div class="d-flex flex-wrap gap-2 mb-3">
        <button class="category-pill" [class.active]="filterCat===''" (click)="filterCat='';applyFilter()">All</button>
        <button class="category-pill" *ngFor="let c of categories" [class.active]="filterCat===c" (click)="filterCat=c;applyFilter()">{{c}}</button>
      </div>

      <!-- Loading -->
      <div class="text-center py-5" *ngIf="loading">
        <div class="spinner-border text-success"></div>
      </div>

      <!-- Products Table -->
      <div class="card border-0 shadow-sm" *ngIf="!loading">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr>
                <th>Product</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let p of filteredProducts">
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <img [src]="p.imageUrl" style="width:48px;height:48px;object-fit:cover;border-radius:8px;">
                    <div>
                      <div class="fw-semibold">{{p.name}}</div>
                      <small class="text-muted">{{p.description | slice:0:40}}...</small>
                    </div>
                  </div>
                </td>
                <td><span class="badge bg-secondary">{{p.category}}</span></td>
                <td class="fw-bold text-success">₹{{p.price}}</td>
                <td>{{p.stockQuantity}}</td>
                <td>
                  <span class="badge-in-stock" *ngIf="p.isInStock">In Stock</span>
                  <span class="badge-out-of-stock" *ngIf="!p.isInStock">Out of Stock</span>
                </td>
                <td>
                  <button class="btn btn-sm btn-outline-primary me-1" (click)="openModal(p)">
                    <i class="bi bi-pencil"></i>
                  </button>
                  <button class="btn btn-sm btn-outline-danger" (click)="deleteProduct(p._id)">
                    <i class="bi bi-trash"></i>
                  </button>
                </td>
              </tr>
              <tr *ngIf="filteredProducts.length === 0">
                <td colspan="6" class="text-center text-muted py-4">No products found.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Add/Edit Modal -->
    <div class="modal fade show d-block" style="background:rgba(0,0,0,0.5);" *ngIf="showModal">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title fw-bold">{{ editingProduct ? 'Edit Product' : 'Add New Product' }}</h5>
            <button class="btn-close" (click)="closeModal()"></button>
          </div>
          <div class="modal-body">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label fw-semibold">Product Name *</label>
                <input type="text" class="form-control" [(ngModel)]="form.name" placeholder="e.g. Basmati Rice">
              </div>
              <div class="col-md-6">
                <label class="form-label fw-semibold">Category *</label>
                <select class="form-select" [(ngModel)]="form.category">
                  <option value="">Select Category</option>
                  <option *ngFor="let c of categories" [value]="c">{{c}}</option>
                </select>
              </div>
              <div class="col-12">
                <label class="form-label fw-semibold">Description *</label>
                <textarea class="form-control" [(ngModel)]="form.description" rows="2" placeholder="Product description"></textarea>
              </div>
              <div class="col-md-4">
                <label class="form-label fw-semibold">Price (₹) *</label>
                <input type="number" class="form-control" [(ngModel)]="form.price" min="0" placeholder="0">
              </div>
              <div class="col-md-4">
                <label class="form-label fw-semibold">Stock Quantity *</label>
                <input type="number" class="form-control" [(ngModel)]="form.stockQuantity" min="0" placeholder="0">
              </div>
              <div class="col-md-4">
                <label class="form-label fw-semibold">Image URL</label>
                <input type="text" class="form-control" [(ngModel)]="form.imageUrl" placeholder="https://...">
              </div>
              <div class="col-12" *ngIf="formError">
                <div class="alert alert-danger mb-0">{{formError}}</div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" (click)="closeModal()">Cancel</button>
            <button class="btn btn-success fw-semibold" (click)="saveProduct()" [disabled]="saving">
              <span *ngIf="saving" class="spinner-border spinner-border-sm me-1"></span>
              {{ saving ? 'Saving...' : (editingProduct ? 'Update Product' : 'Add Product') }}
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  loading = true;
  showModal = false;
  saving = false;
  editingProduct: Product | null = null;
  filterCat = '';
  successMsg = '';
  errorMsg = '';
  formError = '';
  categories = ['Groceries', 'Vegetables', 'Fruits', 'Household', 'Ice-cream'];

  form = { name: '', description: '', category: '', price: 0, stockQuantity: 0, imageUrl: '' };

  constructor(private productSvc: ProductService) {}

  ngOnInit(): void { this.loadProducts(); }

  loadProducts(): void {
    this.loading = true;
    this.productSvc.getProducts().subscribe({
      next: (res) => { this.products = res.products; this.applyFilter(); this.loading = false; },
      error: () => this.loading = false
    });
  }

  applyFilter(): void {
    this.filteredProducts = this.filterCat
      ? this.products.filter(p => p.category === this.filterCat)
      : [...this.products];
  }

  openModal(product?: Product): void {
    this.formError = '';
    if (product) {
      this.editingProduct = product;
      this.form = { name: product.name, description: product.description, category: product.category, price: product.price, stockQuantity: product.stockQuantity, imageUrl: product.imageUrl };
    } else {
      this.editingProduct = null;
      this.form = { name: '', description: '', category: '', price: 0, stockQuantity: 0, imageUrl: '' };
    }
    this.showModal = true;
  }

  closeModal(): void { this.showModal = false; }

  saveProduct(): void {
    if (!this.form.name || !this.form.category || !this.form.description) {
      this.formError = 'Please fill all required fields.'; return;
    }
    this.saving = true;
    this.formError = '';
    const obs = this.editingProduct
      ? this.productSvc.updateProduct(this.editingProduct._id, this.form)
      : this.productSvc.createProduct(this.form);

    obs.subscribe({
      next: () => {
        this.successMsg = this.editingProduct ? 'Product updated successfully!' : 'Product added successfully!';
        this.saving = false;
        this.closeModal();
        this.loadProducts();
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: (err) => {
        this.formError = err.error?.message || 'Operation failed.';
        this.saving = false;
      }
    });
  }

  deleteProduct(id: string): void {
    if (!confirm('Are you sure you want to delete this product?')) return;
    this.productSvc.deleteProduct(id).subscribe({
      next: () => {
        this.successMsg = 'Product deleted.';
        this.loadProducts();
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: (err) => this.errorMsg = err.error?.message || 'Delete failed.'
    });
  }
}
