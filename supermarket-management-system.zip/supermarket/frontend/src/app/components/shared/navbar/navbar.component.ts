import { Component, OnInit } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../services/auth.service';
import { CartService } from '../../../services/cart.service';
import { User } from '../../../models/models';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark" style="background:#2e7d32;">
      <div class="container">
        <a class="navbar-brand" routerLink="/">
          <i class="bi bi-cart4 me-2"></i>SuperMart
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto align-items-center">

            <!-- Guest Links -->
            <ng-container *ngIf="!isLoggedIn">
              <li class="nav-item"><a class="nav-link" routerLink="/login">Login</a></li>
              <li class="nav-item"><a class="nav-link" routerLink="/register">Register</a></li>
            </ng-container>

            <!-- User Links -->
            <ng-container *ngIf="isLoggedIn && !isAdmin">
              <li class="nav-item"><a class="nav-link" routerLink="/home">Products</a></li>
              <li class="nav-item"><a class="nav-link" routerLink="/orders">My Orders</a></li>
              <li class="nav-item">
                <a class="nav-link position-relative" routerLink="/cart">
                  <i class="bi bi-cart3 fs-5"></i>
                  <span class="cart-badge" *ngIf="cartCount > 0">{{cartCount}}</span>
                </a>
              </li>
            </ng-container>

            <!-- Admin Links -->
            <ng-container *ngIf="isAdmin">
              <li class="nav-item"><a class="nav-link" routerLink="/admin/dashboard">Dashboard</a></li>
              <li class="nav-item"><a class="nav-link" routerLink="/admin/products">Products</a></li>
              <li class="nav-item"><a class="nav-link" routerLink="/admin/users">Users</a></li>
              <li class="nav-item"><a class="nav-link" routerLink="/admin/orders">Orders</a></li>
            </ng-container>

            <!-- Logged-in User Info -->
            <li class="nav-item ms-3" *ngIf="isLoggedIn">
              <span class="navbar-text text-white-50 me-2">Hi, {{user?.name}}</span>
              <button class="btn btn-outline-light btn-sm" (click)="logout()">
                <i class="bi bi-box-arrow-right"></i> Logout
              </button>
            </li>

          </ul>
        </div>
      </div>
    </nav>
  `
})
export class NavbarComponent implements OnInit {
  user: User | null = null;
  cartCount = 0;

  constructor(private auth: AuthService, private cart: CartService) {}

  ngOnInit(): void {
    this.auth.currentUser$.subscribe(u => this.user = u);
    this.cart.cartItems$.subscribe(() => this.cartCount = this.cart.totalItems);
  }

  get isLoggedIn() { return this.auth.isLoggedIn; }
  get isAdmin() { return this.auth.isAdmin; }
  logout() { this.auth.logout(); }
}
