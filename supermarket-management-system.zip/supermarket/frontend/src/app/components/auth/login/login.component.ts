import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="min-vh-100 d-flex align-items-center justify-content-center" style="background: linear-gradient(135deg,#2e7d32,#66bb6a);">
      <div class="card shadow-lg p-4" style="width:100%;max-width:420px;border-radius:16px;">
        <div class="text-center mb-4">
          <i class="bi bi-cart4 text-success" style="font-size:3rem;"></i>
          <h3 class="fw-bold mt-2">SuperMart Login</h3>
          <p class="text-muted">Sign in to your account</p>
        </div>

        <div class="alert alert-danger" *ngIf="error">{{error}}</div>

        <form (ngSubmit)="onSubmit()">
          <div class="mb-3">
            <label class="form-label fw-semibold">Email Address</label>
            <input type="email" class="form-control" [(ngModel)]="email" name="email" placeholder="you@example.com" required>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Password</label>
            <input type="password" class="form-control" [(ngModel)]="password" name="password" placeholder="••••••••" required>
          </div>
          <button type="submit" class="btn btn-success w-100 py-2 fw-semibold" [disabled]="loading">
            <span *ngIf="loading" class="spinner-border spinner-border-sm me-2"></span>
            {{ loading ? 'Signing in...' : 'Sign In' }}
          </button>
        </form>

        <hr>
        <p class="text-center mb-0">Don't have an account? <a routerLink="/register" class="text-success fw-semibold">Register</a></p>
      </div>
    </div>
  `
})
export class LoginComponent {
  email = '';
  password = '';
  loading = false;
  error = '';

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    this.loading = true;
    this.error = '';
    this.auth.login({ email: this.email, password: this.password }).subscribe({
      next: (res) => {
        this.router.navigate([res.user.role === 'admin' ? '/admin/dashboard' : '/home']);
      },
      error: (err) => {
        this.error = err.error?.message || 'Login failed. Please try again.';
        this.loading = false;
      }
    });
  }
}
