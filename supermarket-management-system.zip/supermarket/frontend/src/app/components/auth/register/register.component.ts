import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="min-vh-100 d-flex align-items-center justify-content-center" style="background: linear-gradient(135deg,#2e7d32,#66bb6a);">
      <div class="card shadow-lg p-4" style="width:100%;max-width:460px;border-radius:16px;">
        <div class="text-center mb-4">
          <i class="bi bi-person-plus text-success" style="font-size:3rem;"></i>
          <h3 class="fw-bold mt-2">Create Account</h3>
          <p class="text-muted">Join SuperMart today</p>
        </div>

        <div class="alert alert-danger" *ngIf="error">{{error}}</div>
        <div class="alert alert-success" *ngIf="success">{{success}}</div>

        <form (ngSubmit)="onSubmit()">
          <div class="mb-3">
            <label class="form-label fw-semibold">Full Name</label>
            <input type="text" class="form-control" [(ngModel)]="name" name="name" placeholder="John Doe" required>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Email Address</label>
            <input type="email" class="form-control" [(ngModel)]="email" name="email" placeholder="you@example.com" required>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Password</label>
            <input type="password" class="form-control" [(ngModel)]="password" name="password" placeholder="Min 6 characters" required>
          </div>
          <div class="mb-4">
            <label class="form-label fw-semibold">Account Type</label>
            <select class="form-select" [(ngModel)]="role" name="role">
              <option value="user">Customer</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <button type="submit" class="btn btn-success w-100 py-2 fw-semibold" [disabled]="loading">
            <span *ngIf="loading" class="spinner-border spinner-border-sm me-2"></span>
            {{ loading ? 'Creating...' : 'Create Account' }}
          </button>
        </form>

        <hr>
        <p class="text-center mb-0">Already have an account? <a routerLink="/login" class="text-success fw-semibold">Sign In</a></p>
      </div>
    </div>
  `
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  role = 'user';
  loading = false;
  error = '';
  success = '';

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    this.loading = true;
    this.error = '';
    this.auth.register({ name: this.name, email: this.email, password: this.password, role: this.role }).subscribe({
      next: (res) => {
        this.router.navigate([res.user.role === 'admin' ? '/admin/dashboard' : '/home']);
      },
      error: (err) => {
        this.error = err.error?.message || 'Registration failed.';
        this.loading = false;
      }
    });
  }
}
