import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CartService } from '../../../services/cart.service';
import { OrderService } from '../../../services/order.service';
import { CartItem } from '../../../models/models';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="container py-5">
      <h2 class="fw-bold mb-4"><i class="bi bi-cart3 me-2 text-success"></i>Shopping Cart</h2>

      <div class="alert alert-success" *ngIf="successMsg">
        <i class="bi bi-check-circle me-2"></i>{{successMsg}}
      </div>
      <div class="alert alert-danger" *ngIf="errorMsg">{{errorMsg}}</div>

      <!-- Empty Cart -->
      <div class="text-center py-5" *ngIf="items.length === 0">
        <i class="bi bi-cart-x text-muted" style="font-size:4rem;"></i>
        <h4 class="mt-3 text-muted">Your cart is empty</h4>
        <a routerLink="/home" class="btn btn-success mt-3">Continue Shopping</a>
      </div>

      <!-- Cart Items -->
      <div class="row" *ngIf="items.length > 0">
        <div class="col-lg-8">
          <div class="card mb-3 border-0 shadow-sm" *ngFor="let item of items">
            <div class="card-body d-flex align-items-center gap-3">
              <img [src]="item.product.imageUrl" [alt]="item.product.name" style="width:80px;height:80px;object-fit:cover;border-radius:8px;">
              <div class="flex-grow-1">
                <h6 class="mb-0 fw-bold">{{item.product.name}}</h6>
                <small class="text-muted">{{item.product.category}}</small>
                <div class="text-success fw-bold">₹{{item.product.price}}</div>
              </div>
              <div class="d-flex align-items-center gap-2">
                <button class="btn btn-outline-secondary btn-sm" (click)="updateQty(item, item.quantity - 1)">-</button>
                <span class="px-2 fw-bold">{{item.quantity}}</span>
                <button class="btn btn-outline-secondary btn-sm" (click)="updateQty(item, item.quantity + 1)">+</button>
              </div>
              <div class="text-end" style="min-width:80px;">
                <div class="fw-bold">₹{{item.product.price * item.quantity}}</div>
                <button class="btn btn-sm btn-link text-danger p-0" (click)="remove(item.product._id)">
                  <i class="bi bi-trash"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Order Summary -->
        <div class="col-lg-4">
          <div class="card border-0 shadow-sm">
            <div class="card-body">
              <h5 class="fw-bold mb-3">Order Summary</h5>
              <div class="d-flex justify-content-between mb-2" *ngFor="let item of items">
                <span class="text-muted">{{item.product.name}} x{{item.quantity}}</span>
                <span>₹{{item.product.price * item.quantity}}</span>
              </div>
              <hr>
              <div class="d-flex justify-content-between fw-bold fs-5">
                <span>Total</span>
                <span class="text-success">₹{{totalPrice}}</span>
              </div>
              <div class="mb-3 mt-3">
                <label class="form-label fw-semibold">Shipping Address</label>
                <textarea class="form-control" [(ngModel)]="address" rows="2" placeholder="Enter delivery address"></textarea>
              </div>
              <button class="btn btn-success w-100 py-2 fw-semibold" (click)="placeOrder()" [disabled]="placing">
                <span *ngIf="placing" class="spinner-border spinner-border-sm me-2"></span>
                {{ placing ? 'Placing Order...' : 'Place Order' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CartComponent implements OnInit {
  items: CartItem[] = [];
  address = '';
  placing = false;
  successMsg = '';
  errorMsg = '';

  constructor(private cartSvc: CartService, private orderSvc: OrderService) {}

  ngOnInit(): void {
    this.cartSvc.cartItems$.subscribe(items => this.items = items);
  }

  get totalPrice() { return this.cartSvc.totalPrice; }

  updateQty(item: CartItem, qty: number): void {
    this.cartSvc.updateQuantity(item.product._id, qty);
  }

  remove(id: string): void {
    this.cartSvc.removeFromCart(id);
  }

  placeOrder(): void {
    if (!this.address.trim()) { this.errorMsg = 'Please enter a shipping address.'; return; }
    this.placing = true;
    this.errorMsg = '';
    const products = this.items.map(i => ({ productId: i.product._id, quantity: i.quantity }));
    this.orderSvc.placeOrder({ products, shippingAddress: this.address }).subscribe({
      next: () => {
        this.cartSvc.clearCart();
        this.successMsg = 'Order placed successfully! Thank you for shopping with us.';
        this.placing = false;
      },
      error: (err) => {
        this.errorMsg = err.error?.message || 'Order failed. Please try again.';
        this.placing = false;
      }
    });
  }
}
