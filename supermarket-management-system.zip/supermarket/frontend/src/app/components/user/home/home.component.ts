import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../../services/product.service';
import { CartService } from '../../../services/cart.service';
import { Product } from '../../../models/models';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container py-4">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0"><i class="bi bi-shop me-2 text-success"></i>Our Products</h2>
        <input type="text" class="form-control w-auto" [(ngModel)]="searchTerm" (input)="filterProducts()" placeholder="🔍 Search products...">
      </div>

      <!-- Category Pills -->
      <div class="d-flex flex-wrap gap-2 mb-4">
        <button class="category-pill" [class.active]="selectedCategory===''" (click)="filterByCategory('')">All</button>
        <button class="category-pill" *ngFor="let cat of categories" [class.active]="selectedCategory===cat" (click)="filterByCategory(cat)">
          {{cat}}
        </button>
      </div>

      <!-- Loading Spinner -->
      <div class="text-center py-5" *ngIf="loading">
        <div class="spinner-border text-success"></div>
      </div>

      <!-- Toast Notification -->
      <div class="position-fixed bottom-0 end-0 p-3" style="z-index:9999" *ngIf="toastMsg">
        <div class="toast show align-items-center text-white bg-success border-0">
          <div class="d-flex">
            <div class="toast-body"><i class="bi bi-check-circle me-2"></i>{{toastMsg}}</div>
          </div>
        </div>
      </div>

      <!-- Products Grid -->
      <div class="row g-4" *ngIf="!loading">
        <div class="col-6 col-md-4 col-lg-3" *ngFor="let product of filteredProducts">
          <div class="card product-card h-100">
            <img [src]="product.imageUrl" [alt]="product.name">
            <div class="card-body d-flex flex-column">
              <span class="badge bg-secondary mb-2 align-self-start">{{product.category}}</span>
              <h6 class="card-title fw-bold">{{product.name}}</h6>
              <p class="card-text text-muted small flex-grow-1">{{product.description | slice:0:60}}...</p>
              <div class="d-flex justify-content-between align-items-center mt-2">
                <span class="fw-bold text-success fs-5">₹{{product.price}}</span>
                <span class="badge-in-stock" *ngIf="product.isInStock">In Stock</span>
                <span class="badge-out-of-stock" *ngIf="!product.isInStock">Out of Stock</span>
              </div>
              <small class="text-muted mt-1">Qty: {{product.stockQuantity}}</small>
              <button class="btn btn-success mt-3 btn-sm fw-semibold"
                [disabled]="!product.isInStock"
                (click)="addToCart(product)">
                <i class="bi bi-cart-plus me-1"></i> Add to Cart
              </button>
            </div>
          </div>
        </div>

        <div class="col-12 text-center py-5" *ngIf="filteredProducts.length === 0">
          <i class="bi bi-search text-muted" style="font-size:3rem;"></i>
          <p class="text-muted mt-2">No products found.</p>
        </div>
      </div>
    </div>
  `
})
export class HomeComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  loading = true;
  selectedCategory = '';
  searchTerm = '';
  toastMsg = '';
  categories = ['Groceries', 'Vegetables', 'Fruits', 'Household', 'Ice-cream'];

  constructor(private productSvc: ProductService, private cartSvc: CartService) {}

  ngOnInit(): void {
    this.productSvc.getProducts().subscribe({
      next: (res) => {
        this.products = res.products;
        this.filteredProducts = res.products;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  filterByCategory(cat: string): void {
    this.selectedCategory = cat;
    this.filterProducts();
  }

  filterProducts(): void {
    this.filteredProducts = this.products.filter(p => {
      const matchCat = !this.selectedCategory || p.category === this.selectedCategory;
      const matchSearch = !this.searchTerm || p.name.toLowerCase().includes(this.searchTerm.toLowerCase());
      return matchCat && matchSearch;
    });
  }

  addToCart(product: Product): void {
    this.cartSvc.addToCart(product);
    this.toastMsg = `${product.name} added to cart!`;
    setTimeout(() => this.toastMsg = '', 2500);
  }
}
