import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderService } from '../../../services/order.service';
import { Order } from '../../../models/models';

@Component({
  selector: 'app-my-orders',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container py-5">
      <h2 class="fw-bold mb-4"><i class="bi bi-bag-check me-2 text-success"></i>My Orders</h2>

      <div class="text-center py-5" *ngIf="loading">
        <div class="spinner-border text-success"></div>
      </div>

      <div class="text-center py-5" *ngIf="!loading && orders.length === 0">
        <i class="bi bi-bag-x text-muted" style="font-size:3rem;"></i>
        <p class="text-muted mt-2">No orders placed yet.</p>
      </div>

      <div class="card border-0 shadow-sm mb-4" *ngFor="let order of orders">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
          <div>
            <strong>Order #{{order._id.slice(-8).toUpperCase()}}</strong>
            <small class="text-muted ms-2">{{order.createdAt | date:'mediumDate'}}</small>
          </div>
          <span class="badge rounded-pill" [ngClass]="getStatusClass(order.status)">{{order.status | titlecase}}</span>
        </div>
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-2" *ngFor="let item of order.products">
            <span>{{item.name}} <span class="text-muted">x{{item.quantity}}</span></span>
            <span>₹{{item.price * item.quantity}}</span>
          </div>
          <hr>
          <div class="d-flex justify-content-between fw-bold">
            <span>Total</span>
            <span class="text-success">₹{{order.totalAmount}}</span>
          </div>
          <small class="text-muted"><i class="bi bi-geo-alt me-1"></i>{{order.shippingAddress}}</small>
        </div>
      </div>
    </div>
  `
})
export class MyOrdersComponent implements OnInit {
  orders: Order[] = [];
  loading = true;

  constructor(private orderSvc: OrderService) {}

  ngOnInit(): void {
    this.orderSvc.getMyOrders().subscribe({
      next: (res) => { this.orders = res.orders; this.loading = false; },
      error: () => this.loading = false
    });
  }

  getStatusClass(status: string): string {
    const map: any = {
      pending: 'bg-warning text-dark',
      processing: 'bg-info text-dark',
      shipped: 'bg-primary',
      delivered: 'bg-success',
      cancelled: 'bg-danger'
    };
    return map[status] || 'bg-secondary';
  }
}
