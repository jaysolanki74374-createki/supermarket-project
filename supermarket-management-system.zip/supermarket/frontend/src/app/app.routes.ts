import { Routes } from '@angular/router';
import { authGuard, adminGuard, guestGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },

  // Auth Routes
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import('./components/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    canActivate: [guestGuard],
    loadComponent: () => import('./components/auth/register/register.component').then(m => m.RegisterComponent)
  },

  // User Routes
  {
    path: 'home',
    canActivate: [authGuard],
    loadComponent: () => import('./components/user/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'cart',
    canActivate: [authGuard],
    loadComponent: () => import('./components/user/cart/cart.component').then(m => m.CartComponent)
  },
  {
    path: 'orders',
    canActivate: [authGuard],
    loadComponent: () => import('./components/user/my-orders/my-orders.component').then(m => m.MyOrdersComponent)
  },

  // Admin Routes
  {
    path: 'admin/dashboard',
    canActivate: [adminGuard],
    loadComponent: () => import('./components/admin/dashboard/dashboard.component').then(m => m.DashboardComponent)
  },
  {
    path: 'admin/products',
    canActivate: [adminGuard],
    loadComponent: () => import('./components/admin/products/products.component').then(m => m.ProductsComponent)
  },
  {
    path: 'admin/users',
    canActivate: [adminGuard],
    loadComponent: () => import('./components/admin/users/users.component').then(m => m.UsersComponent)
  },
  {
    path: 'admin/orders',
    canActivate: [adminGuard],
    loadComponent: () => import('./components/admin/orders/orders.component').then(m => m.OrdersComponent)
  },

  { path: '**', redirectTo: '/home' }
];
