import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Order } from '../models/models';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private apiUrl = `${environment.apiUrl}/orders`;

  constructor(private http: HttpClient) {}

  placeOrder(data: { products: { productId: string; quantity: number }[]; shippingAddress: string }): Observable<{ success: boolean; order: Order }> {
    return this.http.post<{ success: boolean; order: Order }>(this.apiUrl, data);
  }

  getMyOrders(): Observable<{ success: boolean; orders: Order[] }> {
    return this.http.get<{ success: boolean; orders: Order[] }>(`${this.apiUrl}/my`);
  }

  getAllOrders(): Observable<{ success: boolean; orders: Order[] }> {
    return this.http.get<{ success: boolean; orders: Order[] }>(this.apiUrl);
  }

  updateOrderStatus(id: string, status: string): Observable<{ success: boolean; order: Order }> {
    return this.http.put<{ success: boolean; order: Order }>(`${this.apiUrl}/${id}/status`, { status });
  }
}
