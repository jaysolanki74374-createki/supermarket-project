import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CartItem, Product } from '../models/models';

@Injectable({ providedIn: 'root' })
export class CartService {
  private cartItemsSubject = new BehaviorSubject<CartItem[]>(this.loadCart());
  cartItems$ = this.cartItemsSubject.asObservable();

  private loadCart(): CartItem[] {
    const saved = localStorage.getItem('supermarket_cart');
    return saved ? JSON.parse(saved) : [];
  }

  private saveCart(items: CartItem[]): void {
    localStorage.setItem('supermarket_cart', JSON.stringify(items));
    this.cartItemsSubject.next(items);
  }

  get items(): CartItem[] {
    return this.cartItemsSubject.value;
  }

  get totalItems(): number {
    return this.items.reduce((sum, item) => sum + item.quantity, 0);
  }

  get totalPrice(): number {
    return this.items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  }

  addToCart(product: Product, quantity = 1): void {
    const items = [...this.items];
    const idx = items.findIndex(i => i.product._id === product._id);
    if (idx > -1) {
      items[idx] = { ...items[idx], quantity: items[idx].quantity + quantity };
    } else {
      items.push({ product, quantity });
    }
    this.saveCart(items);
  }

  updateQuantity(productId: string, quantity: number): void {
    if (quantity <= 0) { this.removeFromCart(productId); return; }
    const items = this.items.map(i =>
      i.product._id === productId ? { ...i, quantity } : i
    );
    this.saveCart(items);
  }

  removeFromCart(productId: string): void {
    this.saveCart(this.items.filter(i => i.product._id !== productId));
  }

  clearCart(): void {
    this.saveCart([]);
  }
}
