// User model
export interface User {
  _id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
}

// Product model
export interface Product {
  _id: string;
  name: string;
  description: string;
  category: 'Groceries' | 'Vegetables' | 'Fruits' | 'Household' | 'Ice-cream';
  price: number;
  stockQuantity: number;
  imageUrl: string;
  isInStock: boolean;
  createdAt?: string;
}

// Cart Item model
export interface CartItem {
  product: Product;
  quantity: number;
}

// Order model
export interface Order {
  _id: string;
  user: User | string;
  products: { product: Product; name: string; price: number; quantity: number }[];
  totalAmount: number;
  status: string;
  shippingAddress: string;
  createdAt: string;
}

// Auth response model
export interface AuthResponse {
  success: boolean;
  token: string;
  user: User;
}

// Dashboard stats model
export interface DashboardStats {
  totalProducts: number;
  totalUsers: number;
  totalOrders: number;
  outOfStock: number;
}
