/**
 * Seed Script — Supermarket Management System
 * Run: node seed.js
 * This creates an admin user and sample products in MongoDB.
 */

const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

const User = require('./models/User');
const Product = require('./models/Product');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/supermarket_db';

const sampleProducts = [
  { name: 'Basmati Rice 5kg', description: 'Premium long grain basmati rice', category: 'Groceries', price: 350, stockQuantity: 100, imageUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=300' },
  { name: 'Atta Wheat Flour 10kg', description: 'Whole wheat flour for chapatis', category: 'Groceries', price: 420, stockQuantity: 80, imageUrl: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=300' },
  { name: 'Toor Dal 1kg', description: 'Split pigeon peas for dal', category: 'Groceries', price: 140, stockQuantity: 0, imageUrl: 'https://images.unsplash.com/photo-1599490659213-e2b9527bd087?w=300' },
  { name: 'Fresh Tomatoes 1kg', description: 'Farm fresh red tomatoes', category: 'Vegetables', price: 40, stockQuantity: 50, imageUrl: 'https://images.unsplash.com/photo-1546094096-0df4bcaaa337?w=300' },
  { name: 'Onions 1kg', description: 'Fresh onions from local farms', category: 'Vegetables', price: 35, stockQuantity: 60, imageUrl: 'https://images.unsplash.com/photo-1580201092675-a0a6a6cafbb1?w=300' },
  { name: 'Spinach Bunch', description: 'Fresh green spinach leaves', category: 'Vegetables', price: 25, stockQuantity: 30, imageUrl: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=300' },
  { name: 'Alphonso Mangoes 1kg', description: 'King of fruits — sweet alphonso mangoes', category: 'Fruits', price: 280, stockQuantity: 25, imageUrl: 'https://images.unsplash.com/photo-1553279768-865429fa0078?w=300' },
  { name: 'Bananas 1 dozen', description: 'Ripe yellow bananas', category: 'Fruits', price: 60, stockQuantity: 40, imageUrl: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=300' },
  { name: 'Watermelon', description: 'Fresh seedless watermelon ~3kg', category: 'Fruits', price: 80, stockQuantity: 0, imageUrl: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=300' },
  { name: 'Surf Excel Detergent 1kg', description: 'Powerful stain remover detergent powder', category: 'Household', price: 185, stockQuantity: 70, imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300' },
  { name: 'Dettol Hand Wash 250ml', description: 'Antibacterial liquid hand wash', category: 'Household', price: 99, stockQuantity: 55, imageUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=300' },
  { name: 'Colin Glass Cleaner 500ml', description: 'Crystal clear glass cleaner spray', category: 'Household', price: 120, stockQuantity: 0, imageUrl: 'https://images.unsplash.com/photo-1563453392212-326f5e854473?w=300' },
  { name: 'Vanilla Ice Cream 500ml', description: 'Classic creamy vanilla ice cream', category: 'Ice-cream', price: 145, stockQuantity: 20, imageUrl: 'https://images.unsplash.com/photo-1570197571499-166b36435e9f?w=300' },
  { name: 'Chocolate Ice Cream 500ml', description: 'Rich dark chocolate ice cream', category: 'Ice-cream', price: 155, stockQuantity: 15, imageUrl: 'https://images.unsplash.com/photo-1567206563114-c179706a56b2?w=300' },
  { name: 'Strawberry Ice Cream 500ml', description: 'Fresh strawberry flavoured ice cream', category: 'Ice-cream', price: 150, stockQuantity: 0, imageUrl: 'https://images.unsplash.com/photo-1488900128323-21503983a07e?w=300' },
];

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ MongoDB connected');

    // Clear existing data
    await User.deleteMany({});
    await Product.deleteMany({});
    console.log('🗑  Cleared existing data');

    // Create admin user
    await User.create({
      name: 'Super Admin',
      email: 'admin@supermart.com',
      password: 'admin123',
      role: 'admin'
    });
    console.log('👤 Admin created — email: admin@supermart.com / password: admin123');

    // Create sample user
    await User.create({
      name: 'John Customer',
      email: 'user@supermart.com',
      password: 'user123',
      role: 'user'
    });
    console.log('👤 User created — email: user@supermart.com / password: user123');

    // Insert products
    await Product.insertMany(sampleProducts);
    console.log(`📦 ${sampleProducts.length} products seeded`);

    console.log('\n🎉 Seed complete! You can now start the server.');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err);
    process.exit(1);
  }
}

seed();
