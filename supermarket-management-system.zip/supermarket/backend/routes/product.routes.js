const express = require('express');
const router = express.Router();
const {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  getStats,
} = require('../controllers/product.controller');
const { protect, adminOnly } = require('../middleware/auth.middleware');

// Public routes
router.get('/', getProducts);
router.get('/stats', protect, adminOnly, getStats);
router.get('/:id', getProductById);

// Admin only routes
router.post('/', protect, adminOnly, createProduct);
router.put('/:id', protect, adminOnly, updateProduct);
router.delete('/:id', protect, adminOnly, deleteProduct);

module.exports = router;
